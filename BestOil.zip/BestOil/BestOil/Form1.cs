﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BestOil
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void comboBoxGasoline_SelectedIndexChanged(object sender, EventArgs e)
        {
            var selectedItem = comboBoxGasoline.SelectedItem.ToString();
            if(selectedItem == "សាំង ធម្មតា")
            {
                txtPrice.Text = "4150";
            }else if(selectedItem == "សាំង​ ស៊ុបពែ")
            {
                txtPrice.Text = "4850";
            }else if(selectedItem == "សាំង ម៉ាស៊ូត")
            {
                txtPrice.Text = "4050";
            }else
            {
                txtPrice.Text = "3550";
            }
        }

        private void radioamountChange(object sender, EventArgs e)
        {
            txtAmountFill.Enabled = rdoBtnAmount.Checked;
            txtAmountPrice.Enabled = rdoBtnAmount2.Checked;
            calculateGasPrice();            
        }

        private void calculateGasPrice()
        {
            int price = 0;
            if (rdoBtnAmount.Checked)
            {
                try
                {
                    price = int.Parse(txtPrice.Text) * int.Parse(txtAmountFill.Text);
                }
                catch { }
            }else
            {
                try
                {
                    price = int.Parse(txtAmountPrice.Text);
                }
                catch { }
            }
            lblPayAble.Text = $"{price,4:N0}";
        }

        private void txtAmountFill_TextChanged(object sender, EventArgs e)
        {
            calculateGasPrice();
        }

        private void txtAmountPrice_TextChanged(object sender, EventArgs e)
        {
            calculateGasPrice();
        }

        private void calculateMinicafe()
        {
            int price = 0;
            if (checkBoxHot.Checked)
            {
                try
                {
                    price += int.Parse(txtHotAmount.Text) * int.Parse(txtHotPrice.Text);
                }
                catch { }
            }
            if (checkBoxHambur.Checked)
            {
                try
                {
                    price += int.Parse(txtHamAmount.Text) * int.Parse(txtHamPrice.Text);
                }
                catch { }
               }
            if (checkBoxFrench.Checked)
            {
                try
                {
                    price += int.Parse(txtFrenchAmount.Text) * int.Parse(txtFrenchPrice.Text);
                }
                catch { }
            }
            if (checkBoxCoca.Checked)
            {
                try
                {
                    price += int.Parse(txtCocaAmount.Text) * int.Parse(txtCocaPrice.Text);
                }
                catch { }
            }

            lblMiniPayable.Text = $"{price,4:N0}";

        }

        private void checkchange(object sender, EventArgs e)
        {
            txtHotAmount.Enabled = checkBoxHot.Checked;
            txtHamAmount.Enabled = checkBoxHambur.Checked;
            txtFrenchAmount.Enabled = checkBoxFrench.Checked;
            txtCocaAmount.Enabled = checkBoxCoca.Checked;
            calculateMinicafe();
        }

        private void FoodAmountChange(object sender, EventArgs e)
        {
            calculateMinicafe();
        }

        private void btnCount_Click(object sender, EventArgs e)
        {
            int price =0;
            try
            {
                price = int.Parse(lblPayAble.Text.Replace(",","")) + int.Parse(lblMiniPayable.Text.Replace(",", ""));
            }
            catch { }
            lblCountPayable.Text = $"{price,4:N0}";
        }
    }

}
