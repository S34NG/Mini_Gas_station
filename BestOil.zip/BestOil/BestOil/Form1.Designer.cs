﻿
namespace BestOil
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBoxFillStation = new System.Windows.Forms.GroupBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label4 = new System.Windows.Forms.Label();
            this.lblPayAble = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtAmountPrice = new System.Windows.Forms.TextBox();
            this.txtAmountFill = new System.Windows.Forms.TextBox();
            this.txtPrice = new System.Windows.Forms.TextBox();
            this.comboBoxGasoline = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.lblGasoline = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rdoBtnAmount = new System.Windows.Forms.RadioButton();
            this.rdoBtnAmount2 = new System.Windows.Forms.RadioButton();
            this.groupBoxMiniCafe = new System.Windows.Forms.GroupBox();
            this.txtCocaAmount = new System.Windows.Forms.TextBox();
            this.txtFrenchAmount = new System.Windows.Forms.TextBox();
            this.txtHamAmount = new System.Windows.Forms.TextBox();
            this.txtHotAmount = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtCocaPrice = new System.Windows.Forms.TextBox();
            this.txtFrenchPrice = new System.Windows.Forms.TextBox();
            this.txtHamPrice = new System.Windows.Forms.TextBox();
            this.txtHotPrice = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.checkBoxCoca = new System.Windows.Forms.CheckBox();
            this.checkBoxFrench = new System.Windows.Forms.CheckBox();
            this.checkBoxHambur = new System.Windows.Forms.CheckBox();
            this.checkBoxHot = new System.Windows.Forms.CheckBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label3 = new System.Windows.Forms.Label();
            this.lblMiniPayable = new System.Windows.Forms.Label();
            this.groupBoxTotalPay = new System.Windows.Forms.GroupBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label7 = new System.Windows.Forms.Label();
            this.lblCountPayable = new System.Windows.Forms.Label();
            this.btnCount = new System.Windows.Forms.Button();
            this.groupBoxFillStation.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBoxMiniCafe.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBoxTotalPay.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBoxFillStation
            // 
            this.groupBoxFillStation.Controls.Add(this.label9);
            this.groupBoxFillStation.Controls.Add(this.label8);
            this.groupBoxFillStation.Controls.Add(this.groupBox2);
            this.groupBoxFillStation.Controls.Add(this.label1);
            this.groupBoxFillStation.Controls.Add(this.txtAmountPrice);
            this.groupBoxFillStation.Controls.Add(this.txtAmountFill);
            this.groupBoxFillStation.Controls.Add(this.txtPrice);
            this.groupBoxFillStation.Controls.Add(this.comboBoxGasoline);
            this.groupBoxFillStation.Controls.Add(this.label2);
            this.groupBoxFillStation.Controls.Add(this.lblGasoline);
            this.groupBoxFillStation.Controls.Add(this.groupBox1);
            this.groupBoxFillStation.Location = new System.Drawing.Point(13, 11);
            this.groupBoxFillStation.Name = "groupBoxFillStation";
            this.groupBoxFillStation.Size = new System.Drawing.Size(470, 398);
            this.groupBoxFillStation.TabIndex = 0;
            this.groupBoxFillStation.TabStop = false;
            this.groupBoxFillStation.Text = "Filling Station";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(412, 182);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(53, 29);
            this.label9.TabIndex = 9;
            this.label9.Text = "លីត្រ";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(411, 222);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(52, 29);
            this.label8.TabIndex = 8;
            this.label8.Text = "តម្លៃ";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.lblPayAble);
            this.groupBox2.Font = new System.Drawing.Font("Kh Muol", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.groupBox2.Location = new System.Drawing.Point(6, 282);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(457, 108);
            this.groupBox2.TabIndex = 6;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "ចំនួន ប្រាក់បង់";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label4.Location = new System.Drawing.Point(396, 79);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(50, 28);
            this.label4.TabIndex = 8;
            this.label4.Text = "រៀល";
            // 
            // lblPayAble
            // 
            this.lblPayAble.AutoSize = true;
            this.lblPayAble.Font = new System.Drawing.Font("Segoe UI", 22F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblPayAble.Location = new System.Drawing.Point(239, 33);
            this.lblPayAble.Name = "lblPayAble";
            this.lblPayAble.Size = new System.Drawing.Size(82, 50);
            this.lblPayAble.TabIndex = 0;
            this.lblPayAble.Text = "000";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(377, 105);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(50, 28);
            this.label1.TabIndex = 7;
            this.label1.Text = "រៀល";
            // 
            // txtAmountPrice
            // 
            this.txtAmountPrice.Enabled = false;
            this.txtAmountPrice.Location = new System.Drawing.Point(195, 219);
            this.txtAmountPrice.Name = "txtAmountPrice";
            this.txtAmountPrice.Size = new System.Drawing.Size(199, 36);
            this.txtAmountPrice.TabIndex = 6;
            this.txtAmountPrice.TextChanged += new System.EventHandler(this.txtAmountPrice_TextChanged);
            // 
            // txtAmountFill
            // 
            this.txtAmountFill.Location = new System.Drawing.Point(195, 175);
            this.txtAmountFill.Name = "txtAmountFill";
            this.txtAmountFill.Size = new System.Drawing.Size(199, 36);
            this.txtAmountFill.TabIndex = 5;
            this.txtAmountFill.TextChanged += new System.EventHandler(this.txtAmountFill_TextChanged);
            // 
            // txtPrice
            // 
            this.txtPrice.Enabled = false;
            this.txtPrice.Location = new System.Drawing.Point(143, 95);
            this.txtPrice.Name = "txtPrice";
            this.txtPrice.Size = new System.Drawing.Size(231, 36);
            this.txtPrice.TabIndex = 3;
            // 
            // comboBoxGasoline
            // 
            this.comboBoxGasoline.FormattingEnabled = true;
            this.comboBoxGasoline.Items.AddRange(new object[] {
            "សាំង ធម្មតា",
            "សាំង​ ស៊ុបពែ",
            "សាំង ម៉ាស៊ូត",
            "ហ្គាស"});
            this.comboBoxGasoline.Location = new System.Drawing.Point(143, 48);
            this.comboBoxGasoline.Name = "comboBoxGasoline";
            this.comboBoxGasoline.Size = new System.Drawing.Size(231, 37);
            this.comboBoxGasoline.TabIndex = 2;
            this.comboBoxGasoline.SelectedIndexChanged += new System.EventHandler(this.comboBoxGasoline_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 95);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(52, 29);
            this.label2.TabIndex = 1;
            this.label2.Text = "តម្លៃ";
            // 
            // lblGasoline
            // 
            this.lblGasoline.AutoSize = true;
            this.lblGasoline.Location = new System.Drawing.Point(6, 48);
            this.lblGasoline.Name = "lblGasoline";
            this.lblGasoline.Size = new System.Drawing.Size(52, 29);
            this.lblGasoline.TabIndex = 0;
            this.lblGasoline.Text = "សាំង";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rdoBtnAmount);
            this.groupBox1.Controls.Add(this.rdoBtnAmount2);
            this.groupBox1.Font = new System.Drawing.Font("Kh Muol", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.groupBox1.Location = new System.Drawing.Point(0, 153);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(188, 123);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            // 
            // rdoBtnAmount
            // 
            this.rdoBtnAmount.AutoSize = true;
            this.rdoBtnAmount.Checked = true;
            this.rdoBtnAmount.Font = new System.Drawing.Font("Kh Muol", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.rdoBtnAmount.Location = new System.Drawing.Point(6, 29);
            this.rdoBtnAmount.Name = "rdoBtnAmount";
            this.rdoBtnAmount.Size = new System.Drawing.Size(99, 45);
            this.rdoBtnAmount.TabIndex = 7;
            this.rdoBtnAmount.TabStop = true;
            this.rdoBtnAmount.Text = "ចំនួន";
            this.rdoBtnAmount.UseVisualStyleBackColor = true;
            this.rdoBtnAmount.CheckedChanged += new System.EventHandler(this.radioamountChange);
            // 
            // rdoBtnAmount2
            // 
            this.rdoBtnAmount2.AutoSize = true;
            this.rdoBtnAmount2.Location = new System.Drawing.Point(6, 69);
            this.rdoBtnAmount2.Name = "rdoBtnAmount2";
            this.rdoBtnAmount2.Size = new System.Drawing.Size(99, 45);
            this.rdoBtnAmount2.TabIndex = 6;
            this.rdoBtnAmount2.TabStop = true;
            this.rdoBtnAmount2.Text = "ចំនួន";
            this.rdoBtnAmount2.UseVisualStyleBackColor = true;
            // 
            // groupBoxMiniCafe
            // 
            this.groupBoxMiniCafe.Controls.Add(this.txtCocaAmount);
            this.groupBoxMiniCafe.Controls.Add(this.txtFrenchAmount);
            this.groupBoxMiniCafe.Controls.Add(this.txtHamAmount);
            this.groupBoxMiniCafe.Controls.Add(this.txtHotAmount);
            this.groupBoxMiniCafe.Controls.Add(this.label6);
            this.groupBoxMiniCafe.Controls.Add(this.txtCocaPrice);
            this.groupBoxMiniCafe.Controls.Add(this.txtFrenchPrice);
            this.groupBoxMiniCafe.Controls.Add(this.txtHamPrice);
            this.groupBoxMiniCafe.Controls.Add(this.txtHotPrice);
            this.groupBoxMiniCafe.Controls.Add(this.label5);
            this.groupBoxMiniCafe.Controls.Add(this.checkBoxCoca);
            this.groupBoxMiniCafe.Controls.Add(this.checkBoxFrench);
            this.groupBoxMiniCafe.Controls.Add(this.checkBoxHambur);
            this.groupBoxMiniCafe.Controls.Add(this.checkBoxHot);
            this.groupBoxMiniCafe.Controls.Add(this.groupBox3);
            this.groupBoxMiniCafe.Location = new System.Drawing.Point(500, 11);
            this.groupBoxMiniCafe.Name = "groupBoxMiniCafe";
            this.groupBoxMiniCafe.Size = new System.Drawing.Size(503, 398);
            this.groupBoxMiniCafe.TabIndex = 1;
            this.groupBoxMiniCafe.TabStop = false;
            this.groupBoxMiniCafe.Text = "Mini Cafe";
            // 
            // txtCocaAmount
            // 
            this.txtCocaAmount.Enabled = false;
            this.txtCocaAmount.Location = new System.Drawing.Point(349, 205);
            this.txtCocaAmount.Name = "txtCocaAmount";
            this.txtCocaAmount.Size = new System.Drawing.Size(115, 36);
            this.txtCocaAmount.TabIndex = 21;
            this.txtCocaAmount.TextChanged += new System.EventHandler(this.FoodAmountChange);
            // 
            // txtFrenchAmount
            // 
            this.txtFrenchAmount.Enabled = false;
            this.txtFrenchAmount.Location = new System.Drawing.Point(349, 163);
            this.txtFrenchAmount.Name = "txtFrenchAmount";
            this.txtFrenchAmount.Size = new System.Drawing.Size(115, 36);
            this.txtFrenchAmount.TabIndex = 20;
            this.txtFrenchAmount.TextChanged += new System.EventHandler(this.FoodAmountChange);
            // 
            // txtHamAmount
            // 
            this.txtHamAmount.Enabled = false;
            this.txtHamAmount.Location = new System.Drawing.Point(349, 121);
            this.txtHamAmount.Name = "txtHamAmount";
            this.txtHamAmount.Size = new System.Drawing.Size(115, 36);
            this.txtHamAmount.TabIndex = 19;
            this.txtHamAmount.TextChanged += new System.EventHandler(this.FoodAmountChange);
            // 
            // txtHotAmount
            // 
            this.txtHotAmount.Enabled = false;
            this.txtHotAmount.Location = new System.Drawing.Point(349, 79);
            this.txtHotAmount.Name = "txtHotAmount";
            this.txtHotAmount.Size = new System.Drawing.Size(115, 36);
            this.txtHotAmount.TabIndex = 18;
            this.txtHotAmount.TextChanged += new System.EventHandler(this.FoodAmountChange);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(375, 33);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(61, 29);
            this.label6.TabIndex = 17;
            this.label6.Text = "ចំនួន";
            // 
            // txtCocaPrice
            // 
            this.txtCocaPrice.Enabled = false;
            this.txtCocaPrice.Location = new System.Drawing.Point(213, 205);
            this.txtCocaPrice.Name = "txtCocaPrice";
            this.txtCocaPrice.Size = new System.Drawing.Size(115, 36);
            this.txtCocaPrice.TabIndex = 16;
            this.txtCocaPrice.Text = "2500";
            // 
            // txtFrenchPrice
            // 
            this.txtFrenchPrice.Enabled = false;
            this.txtFrenchPrice.Location = new System.Drawing.Point(213, 163);
            this.txtFrenchPrice.Name = "txtFrenchPrice";
            this.txtFrenchPrice.Size = new System.Drawing.Size(115, 36);
            this.txtFrenchPrice.TabIndex = 15;
            this.txtFrenchPrice.Text = "2500";
            // 
            // txtHamPrice
            // 
            this.txtHamPrice.Enabled = false;
            this.txtHamPrice.Location = new System.Drawing.Point(213, 121);
            this.txtHamPrice.Name = "txtHamPrice";
            this.txtHamPrice.Size = new System.Drawing.Size(115, 36);
            this.txtHamPrice.TabIndex = 14;
            this.txtHamPrice.Text = "6000";
            // 
            // txtHotPrice
            // 
            this.txtHotPrice.Enabled = false;
            this.txtHotPrice.Location = new System.Drawing.Point(213, 79);
            this.txtHotPrice.Name = "txtHotPrice";
            this.txtHotPrice.Size = new System.Drawing.Size(115, 36);
            this.txtHotPrice.TabIndex = 13;
            this.txtHotPrice.Text = "3000";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(237, 33);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(52, 29);
            this.label5.TabIndex = 8;
            this.label5.Text = "តម្លៃ";
            // 
            // checkBoxCoca
            // 
            this.checkBoxCoca.AutoSize = true;
            this.checkBoxCoca.Location = new System.Drawing.Point(6, 208);
            this.checkBoxCoca.Name = "checkBoxCoca";
            this.checkBoxCoca.Size = new System.Drawing.Size(134, 33);
            this.checkBoxCoca.TabIndex = 12;
            this.checkBoxCoca.Text = "Coca Cola";
            this.checkBoxCoca.UseVisualStyleBackColor = true;
            this.checkBoxCoca.CheckedChanged += new System.EventHandler(this.checkchange);
            // 
            // checkBoxFrench
            // 
            this.checkBoxFrench.AutoSize = true;
            this.checkBoxFrench.Location = new System.Drawing.Point(6, 166);
            this.checkBoxFrench.Name = "checkBoxFrench";
            this.checkBoxFrench.Size = new System.Drawing.Size(165, 33);
            this.checkBoxFrench.TabIndex = 11;
            this.checkBoxFrench.Text = "French Fries";
            this.checkBoxFrench.UseVisualStyleBackColor = true;
            this.checkBoxFrench.CheckedChanged += new System.EventHandler(this.checkchange);
            // 
            // checkBoxHambur
            // 
            this.checkBoxHambur.AutoSize = true;
            this.checkBoxHambur.Location = new System.Drawing.Point(6, 124);
            this.checkBoxHambur.Name = "checkBoxHambur";
            this.checkBoxHambur.Size = new System.Drawing.Size(155, 33);
            this.checkBoxHambur.TabIndex = 10;
            this.checkBoxHambur.Text = "Hamburger";
            this.checkBoxHambur.UseVisualStyleBackColor = true;
            this.checkBoxHambur.CheckedChanged += new System.EventHandler(this.checkchange);
            // 
            // checkBoxHot
            // 
            this.checkBoxHot.AutoSize = true;
            this.checkBoxHot.Location = new System.Drawing.Point(6, 81);
            this.checkBoxHot.Name = "checkBoxHot";
            this.checkBoxHot.Size = new System.Drawing.Size(120, 33);
            this.checkBoxHot.TabIndex = 9;
            this.checkBoxHot.Text = "Hot-Dog";
            this.checkBoxHot.UseVisualStyleBackColor = true;
            this.checkBoxHot.CheckedChanged += new System.EventHandler(this.checkchange);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.label3);
            this.groupBox3.Controls.Add(this.lblMiniPayable);
            this.groupBox3.Font = new System.Drawing.Font("Kh Muol", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.groupBox3.Location = new System.Drawing.Point(6, 289);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(457, 108);
            this.groupBox3.TabIndex = 9;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "ចំនួន ប្រាក់បង់";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label3.Location = new System.Drawing.Point(396, 79);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(50, 28);
            this.label3.TabIndex = 8;
            this.label3.Text = "រៀល";
            // 
            // lblMiniPayable
            // 
            this.lblMiniPayable.AutoSize = true;
            this.lblMiniPayable.Font = new System.Drawing.Font("Segoe UI", 22F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblMiniPayable.Location = new System.Drawing.Point(239, 33);
            this.lblMiniPayable.Name = "lblMiniPayable";
            this.lblMiniPayable.Size = new System.Drawing.Size(82, 50);
            this.lblMiniPayable.TabIndex = 0;
            this.lblMiniPayable.Text = "000";
            // 
            // groupBoxTotalPay
            // 
            this.groupBoxTotalPay.Controls.Add(this.pictureBox1);
            this.groupBoxTotalPay.Controls.Add(this.label7);
            this.groupBoxTotalPay.Controls.Add(this.lblCountPayable);
            this.groupBoxTotalPay.Controls.Add(this.btnCount);
            this.groupBoxTotalPay.Location = new System.Drawing.Point(13, 414);
            this.groupBoxTotalPay.Name = "groupBoxTotalPay";
            this.groupBoxTotalPay.Size = new System.Drawing.Size(990, 122);
            this.groupBoxTotalPay.TabIndex = 1;
            this.groupBoxTotalPay.TabStop = false;
            this.groupBoxTotalPay.Text = "Total amount payable ";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::BestOil.Properties.Resources.istockphoto_1147584034_612x612;
            this.pictureBox1.Location = new System.Drawing.Point(81, 41);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(108, 76);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 11;
            this.pictureBox1.TabStop = false;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label7.Location = new System.Drawing.Point(876, 89);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(50, 28);
            this.label7.TabIndex = 10;
            this.label7.Text = "រៀល";
            // 
            // lblCountPayable
            // 
            this.lblCountPayable.AutoSize = true;
            this.lblCountPayable.Font = new System.Drawing.Font("Segoe UI", 22F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblCountPayable.Location = new System.Drawing.Point(718, 42);
            this.lblCountPayable.Name = "lblCountPayable";
            this.lblCountPayable.Size = new System.Drawing.Size(82, 50);
            this.lblCountPayable.TabIndex = 9;
            this.lblCountPayable.Text = "000";
            // 
            // btnCount
            // 
            this.btnCount.BackColor = System.Drawing.Color.DarkGray;
            this.btnCount.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnCount.ForeColor = System.Drawing.Color.Black;
            this.btnCount.Location = new System.Drawing.Point(225, 41);
            this.btnCount.Name = "btnCount";
            this.btnCount.Size = new System.Drawing.Size(230, 71);
            this.btnCount.TabIndex = 9;
            this.btnCount.Text = "Count";
            this.btnCount.UseVisualStyleBackColor = false;
            this.btnCount.Click += new System.EventHandler(this.btnCount_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(14F, 29F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1018, 538);
            this.Controls.Add(this.groupBoxTotalPay);
            this.Controls.Add(this.groupBoxMiniCafe);
            this.Controls.Add(this.groupBoxFillStation);
            this.Font = new System.Drawing.Font("Bradley Hand ITC", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.ForeColor = System.Drawing.SystemColors.MenuText;
            this.Margin = new System.Windows.Forms.Padding(6, 5, 6, 5);
            this.Name = "Form1";
            this.Text = "BestOil";
            this.groupBoxFillStation.ResumeLayout(false);
            this.groupBoxFillStation.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBoxMiniCafe.ResumeLayout(false);
            this.groupBoxMiniCafe.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBoxTotalPay.ResumeLayout(false);
            this.groupBoxTotalPay.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBoxFillStation;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lblPayAble;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtAmountPrice;
        private System.Windows.Forms.TextBox txtAmountFill;
        private System.Windows.Forms.TextBox txtPrice;
        private System.Windows.Forms.ComboBox comboBoxGasoline;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblGasoline;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBoxMiniCafe;
        private System.Windows.Forms.TextBox txtCocaPrice;
        private System.Windows.Forms.TextBox txtFrenchPrice;
        private System.Windows.Forms.TextBox txtHamPrice;
        private System.Windows.Forms.TextBox txtHotPrice;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.CheckBox checkBoxCoca;
        private System.Windows.Forms.CheckBox checkBoxFrench;
        private System.Windows.Forms.CheckBox checkBoxHambur;
        private System.Windows.Forms.CheckBox checkBoxHot;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblMiniPayable;
        private System.Windows.Forms.GroupBox groupBoxTotalPay;
        private System.Windows.Forms.TextBox txtCocaAmount;
        private System.Windows.Forms.TextBox txtFrenchAmount;
        private System.Windows.Forms.TextBox txtHamAmount;
        private System.Windows.Forms.TextBox txtHotAmount;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label lblCountPayable;
        private System.Windows.Forms.Button btnCount;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.RadioButton rdoBtnAmount2;
        private System.Windows.Forms.RadioButton rdoBtnAmount;
    }
}

